-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2023 at 02:52 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `government-application`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminID` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminID`, `firstName`, `lastName`, `email`, `password`) VALUES
(1, 'Moreen', 'Sampang', 'moreen@gmail.com', 'a39f075b760249bccf2d26a6908eb1b5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_application`
--

CREATE TABLE `tbl_application` (
  `FormID` int(10) UNSIGNED NOT NULL,
  `customerID` int(11) NOT NULL,
  `submissionDate` date NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','rejected') NOT NULL,
  `referenceCode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_application`
--

INSERT INTO `tbl_application` (`FormID`, `customerID`, `submissionDate`, `status`, `referenceCode`) VALUES
(13, 35, '2023-12-11', 'pending', '7091774'),
(14, 36, '2023-12-11', 'pending', '6496017'),
(15, 30, '2023-12-11', 'pending', '6340043'),
(16, 32, '2023-12-11', 'pending', '1542800');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customerID` int(10) UNSIGNED NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `middleName` varchar(255) DEFAULT NULL,
  `idType` enum('barangay id','senior citizen','pwd') NOT NULL,
  `dateOfBirth` date NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `bloodType` varchar(255) NOT NULL,
  `countryOfBirth` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `municipalityCity` varchar(255) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `birthCertificate` varchar(255) NOT NULL,
  `proofOfResidency` varchar(255) NOT NULL,
  `clientPicture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customerID`, `firstName`, `lastName`, `middleName`, `idType`, `dateOfBirth`, `gender`, `bloodType`, `countryOfBirth`, `province`, `municipalityCity`, `barangay`, `address`, `birthCertificate`, `proofOfResidency`, `clientPicture`) VALUES
(26, 'voemo', 'meofmo', 'mffeofm', 'senior citizen', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(27, 'voemo', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(28, 'voemo', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(29, 'voemo', 'meofmo', 'mffeofm', 'pwd', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(30, 'voemo', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(31, 'voemo', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(32, 'voeme', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(33, 'Moreen', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(34, 'Moreen', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', '', '', ''),
(35, 'Moreen', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', 'uploads/35/check-green.png', 'uploads/35/government-registration-logo.png', 'uploads/35/1354405.png'),
(36, 'Alyssa', 'meofmo', 'mffeofm', 'barangay id', '2023-11-27', 'male', 'AB', 'vepf', 'mfwom', 'mveom', 'moemfo', 'ofmeomf', 'uploads/36/check-green.png', 'uploads/36/government-registration-logo.png', 'uploads/36/1354405.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `tbl_application`
--
ALTER TABLE `tbl_application`
  ADD PRIMARY KEY (`FormID`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_application`
--
ALTER TABLE `tbl_application`
  MODIFY `FormID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customerID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
