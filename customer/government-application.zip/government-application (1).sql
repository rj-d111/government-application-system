-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2023 at 12:06 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `government-application`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminID` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminID`, `firstName`, `lastName`, `email`, `password`) VALUES
(1, 'Moreen', 'Sampang', 'moreen@gmail.com', 'a39f075b760249bccf2d26a6908eb1b5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_application`
--

CREATE TABLE `tbl_application` (
  `FormID` int(10) UNSIGNED NOT NULL,
  `customerID` int(11) NOT NULL,
  `submissionDate` date NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','rejected') NOT NULL,
  `referenceCode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_application`
--

INSERT INTO `tbl_application` (`FormID`, `customerID`, `submissionDate`, `status`, `referenceCode`) VALUES
(13, 35, '2023-12-11', 'approved', '7091774'),
(14, 36, '2023-12-11', 'rejected', '6496017'),
(15, 30, '2023-12-11', 'rejected', '6340043'),
(16, 32, '2023-12-11', 'rejected', '1542800'),
(17, 37, '2023-12-13', 'rejected', '2238605'),
(23, 38, '2023-12-15', 'pending', '7766549'),
(24, 39, '2023-12-15', 'pending', '7224053'),
(40, 39, '2023-12-15', 'pending', '7102571'),
(41, 40, '2023-12-15', 'pending', '7593217'),
(43, 41, '2023-12-15', 'pending', '9238961'),
(44, 42, '2023-12-15', 'pending', '1888371'),
(45, 43, '2023-12-16', 'pending', '2102778');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customerID` int(10) UNSIGNED NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `middleName` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `idType` enum('barangay id','senior citizen','pwd') NOT NULL,
  `dateOfBirth` date NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `bloodType` varchar(255) NOT NULL,
  `countryOfBirth` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `municipalityCity` varchar(255) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `birthCertificate` varchar(255) NOT NULL,
  `proofOfResidency` varchar(255) NOT NULL,
  `clientPicture` varchar(255) NOT NULL,
  `proofOfDisability` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customerID`, `firstName`, `lastName`, `middleName`, `email`, `idType`, `dateOfBirth`, `gender`, `bloodType`, `countryOfBirth`, `province`, `municipalityCity`, `barangay`, `address`, `birthCertificate`, `proofOfResidency`, `clientPicture`, `proofOfDisability`) VALUES
(26, 'Velo', 'De la Cruz', 'B', 'velo@gmail.com', 'senior citizen', '2023-11-27', 'male', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(27, 'Jason', 'Pascual', 'H', 'jason@gmail.com', 'barangay id', '2023-11-27', 'male', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(28, 'Bella', 'Llano', 'T', 'voeemo2@gmail.com', 'barangay id', '2023-11-27', 'female', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', '2x2picture-female.jpg', 'uploads/43/proof-of-disability.jpg'),
(30, 'Anton', 'Guiral', 'P', 'anton@gmail.com', 'barangay id', '2023-11-27', 'male', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(31, 'Edward', 'De Ocera', '', 'voeemo5@gmail.com', 'barangay id', '2023-11-27', 'male', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(32, 'Justine', 'Cruz', '', 'justine@gmail.com', 'barangay id', '2023-11-27', 'female', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', '2x2picture-female.jpg', 'uploads/43/proof-of-disability.jpg'),
(33, 'Mero', 'Sy', '', 'moreen1@gmail.com', 'barangay id', '2023-11-27', 'male', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(34, 'Moreen', 'Santiago', NULL, 'moreen2@gmail.com', 'barangay id', '2023-11-27', 'female', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', '2x2picture-female.jpg', 'uploads/43/proof-of-disability.jpg'),
(35, 'Mary', 'Grace', 'A', 'mary@gmail.com', 'barangay id', '2023-11-27', 'female', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', '2x2picture-female.jpg', 'uploads/43/proof-of-disability.jpg'),
(36, 'Alyssa', 'Apolona', NULL, 'alyssa1@gmail.com', 'barangay id', '2023-11-27', 'female', 'AB', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', '2x2picture-female.jpg', 'uploads/43/proof-of-disability.jpg'),
(37, 'Jacob', 'San Jose', 'P', 'jacob1@gmail.com', 'senior citizen', '2004-07-01', 'male', 'A', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(38, 'Jello', 'De Ocera', 'A', 'jello@gmail.com', 'barangay id', '2007-03-15', 'male', 'B', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(41, 'Jezmar', 'Max', '', 'jezmar@gmail.com', 'pwd', '2023-10-25', 'male', 'B', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(42, 'Jacob', 'Ramirez', '', 'jacob@gmail.com', 'pwd', '2023-12-07', 'male', 'A', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg'),
(43, 'Richard', 'De la Cruz', 'B', 'richard@gmail.com', 'pwd', '2015-02-03', 'male', 'A', 'Philippines', 'Cavite', 'Dasmariñas', 'Immaculate Conception', 'P. Campos Ave., Dasmariñas', 'uploads/43/birth-certificate.jpg', 'uploads/43/proof-of-residency.jpg', 'uploads/43/picture-2x2.jpeg', 'uploads/43/proof-of-disability.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `tbl_application`
--
ALTER TABLE `tbl_application`
  ADD PRIMARY KEY (`FormID`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customerID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_application`
--
ALTER TABLE `tbl_application`
  MODIFY `FormID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customerID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
